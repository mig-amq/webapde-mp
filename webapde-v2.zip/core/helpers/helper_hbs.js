const users = require('../models/User')
const hbs = require('hbs')

module.exports = [
  /**
   * To add a helper follow this format:
   * [helper_name, (parameters) => {
   *    put code here...
   * }],
   */
]